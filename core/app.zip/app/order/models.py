from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from decimal import Decimal
from ..accounts.validators import validate_iranian_cellphone_number

class TrackingType(models.IntegerChoices):
    post = 1 , "ارسال با پست عادی"
    mahex = 2 , "ارسال با ماهکس"
    tipax = 3 , "ارسال با تیپاکس"
    person = 4, "حضوری"
    

class OrderStatusType(models.IntegerChoices):
    pending = 1 , "در انتظار پرداخت"
    awaiting = 2, "در انتظار تایید سفارش"
    success = 3, "در حال پردازش"
    shipped = 4, "ارسال شده"
    deliverd = 5, "تحویل شده"
    failed = 6,"لغو شده"


class UserAddressModel(models.Model):
    user = models.ForeignKey('accounts.User',on_delete=models.CASCADE)
    name = models.CharField(max_length=250,default="")
    phone_number = models.CharField(max_length=12,default="",validators=[validate_iranian_cellphone_number])
    
    address = models.CharField(max_length=250)
    state = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    zip_code = models.CharField(max_length=50)

    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

class CouponModel(models.Model):
    code = models.CharField(max_length=100)
    discount_percent = models.IntegerField(default=0,validators = [MinValueValidator(0),MaxValueValidator(100)])
    max_limit_usage = models.PositiveIntegerField(default=10)
    used_by = models.ManyToManyField('accounts.User',related_name = "coupon_users",blank=True)
    
    expiration_date = models.DateTimeField(null=True,blank=True)
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.code


# Create your models here.
class OrderModel(models.Model):
    user = models.ForeignKey('accounts.User',on_delete=models.CASCADE,related_name='order_user')
    name = models.CharField(max_length=250,default="")
    phone_number = models.CharField(max_length=250,default="")

    # order address information
    address = models.CharField(max_length=250)
    state = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    zip_code = models.CharField(max_length=50)
    
    payment = models.ForeignKey('payment.PaymentModel',on_delete=models.SET_NULL,null=True,blank=True)
    
    
    total_price = models.DecimalField(default=0,max_digits=10,decimal_places=0)
    coupon = models.ForeignKey(CouponModel,on_delete=models.PROTECT,null=True,blank=True)
    status = models.IntegerField(choices=OrderStatusType.choices,default=OrderStatusType.pending.value)
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)
    tracking_type = models.IntegerField(choices=TrackingType.choices,default=TrackingType.post.value)
    tracking_code = models.CharField(max_length=100, null=True, blank=True, verbose_name="کد رهگیری پستی")
    
    class Meta:
        ordering = ['-created_date']
    
    def calculate_total_price(self):
        return sum(item.price * item.quantity for item in self.order_items.all())
    
    def __str__(self):
        user_email = getattr(self.user, "email", None) or "کاربر نامشخص"
        return f"{user_email} - {self.id}"
    
    def get_status(self):
        return {
            "id":self.status,
            "title":OrderStatusType(self.status).name,
            "label":OrderStatusType(self.status).label,
        }
        
    def get_full_address(self):
        return f"{self.state},{self.city},{self.address}"
    
    @property
    def order_number(self):
        """شماره سفارش به صورت تاریخ + ID"""
        return f"{self.created_date.strftime('%Y%m%d')}{self.id}"
    
    @property
    def is_successful(self):
        return self.status == OrderStatusType.success.value
    
    def get_price(self):
        if self.coupon:
            return round(self.total_price - (self.total_price * Decimal( self.coupon.discount_percent /100)))
        else:
            return self.total_price

    def get_tracking_url(self):
        if self.tracking_code:
            return f"https://mahex.com/tracking?consignmentId={self.tracking_code}"
        return None
    
    
class OrderItemModel(models.Model):
    order = models.ForeignKey(OrderModel,on_delete=models.CASCADE,related_name="order_items") 
    product = models.ForeignKey('shop.ProductModel',on_delete=models.PROTECT)
    color = models.ForeignKey('shop.Color',on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=0)
    price = models.DecimalField(default=0,max_digits=10,decimal_places=0)
    
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.product.title} - {self.order.id}"
    
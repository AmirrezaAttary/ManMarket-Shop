'use strict';


// document.addEventListener('contextmenu', function(e) {
//     e.preventDefault();
// });
//
// document.addEventListener('keydown', function(e) {
//     if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && e.key === 'I') || (e.ctrlKey && e.shiftKey && e.key === 'J')) {
//         e.preventDefault();
//     }
// });
//
// document.addEventListener('contextmenu', function(e) {
//     e.preventDefault();
// });
//
// document.addEventListener('dragstart', function(e) {
//     if (e.target.tagName === 'IMG') {
//         e.preventDefault();
//     }
// });


document.addEventListener('DOMContentLoaded', () => {
    const addToPwaButton = document.getElementById('add-to-pwa');

    if (addToPwaButton) {
        addToPwaButton.addEventListener('click', () => {
            Swal.fire({
                title: 'وب اپلیکیشن من مارکت را به صفحه اصلی خود اضافه کنید',
                html: `
                    <ol style="direction: rtl; text-align: center; margin-right: 20px; margin-top: 20px;">
                        <li style="margin-bottom: 10px;">1 . در نوار پایین گزینه " share " را انتخاب کنید.</li>
                        <li style="margin-bottom: 10px;">2 . در منوی باز شد گزینه <button class="btn bg-light text-dark fs-14 py-1 px-2">+</button> " Add to Home Screen" را انتخاب کنید.</li>
                        <li>3 . در مرحله بعد " Add " را انتخاب کنید.</li>
                    </ol>
                `,
                icon: 'info',
                showConfirmButton: true,
                confirmButtonText: 'متوجه شدم',
                customClass: {
                    confirmButton: 'swal-button-custom'
                },
                didOpen: () => {
                    const infoIcon = Swal.getIcon();
                    if (infoIcon) {
                        infoIcon.style.borderColor = '#f96747';
                        infoIcon.style.color = '#f96747';
                    }
                    const button = Swal.getConfirmButton();
                    if (button) {
                        button.style.backgroundColor = '#f96747';
                    }
                }
            });
        });
    }
});

let PriceIcon = '<svg className="ms-3" width="22" height="22" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path className="text-gray-880 dark:text-white" d="M1.14878 6.91843C1.44428 6.91843 1.70285 6.87142 1.92447 6.77739C2.15282 6.68337 2.34422 6.55577 2.49869 6.39458C2.65316 6.2334 2.77069 6.04535 2.85128 5.83044C2.93187 5.62224 2.97888 5.40062 2.99231 5.16556H1.98492C1.6424 5.16556 1.36033 5.12862 1.1387 5.05474C0.917077 4.98087 0.742461 4.87341 0.614858 4.73238C0.487254 4.59134 0.396588 4.42344 0.34286 4.22868C0.295849 4.0272 0.272343 3.80221 0.272343 3.55372C0.272343 3.29852 0.309281 3.05674 0.383156 2.8284C0.457032 2.60005 0.564488 2.39857 0.705523 2.22396C0.846559 2.04934 1.02117 1.91167 1.22937 1.81093C1.44428 1.70347 1.68941 1.64974 1.96477 1.64974C2.1864 1.64974 2.39795 1.68668 2.59943 1.76056C2.80091 1.83443 2.97888 1.95196 3.13335 2.11315C3.28782 2.26761 3.40871 2.47245 3.49601 2.72766C3.59004 2.97615 3.63705 3.27837 3.63705 3.63431V4.47045H4.60415C4.68474 4.47045 4.73847 4.50068 4.76533 4.56112C4.79891 4.61485 4.8157 4.6988 4.8157 4.81297C4.8157 4.93386 4.79891 5.02452 4.76533 5.08497C4.73847 5.13869 4.68474 5.16556 4.60415 5.16556H3.6169C3.60347 5.49464 3.53631 5.80693 3.41542 6.10244C3.30125 6.39794 3.14007 6.65651 2.93187 6.87813C2.72368 7.09976 2.47518 7.27438 2.1864 7.40198C1.89761 7.5363 1.57188 7.60346 1.20922 7.60346H0.141381L0.0809373 6.91843H1.14878ZM0.896929 3.51343C0.896929 3.68133 0.913719 3.82572 0.947299 3.94661C0.987594 4.0675 1.0514 4.16823 1.1387 4.24883C1.23273 4.3227 1.35697 4.37979 1.51144 4.42008C1.66591 4.45366 1.86067 4.47045 2.09573 4.47045H3.00239V3.71491C3.00239 3.21792 2.90501 2.86198 2.71024 2.64707C2.51548 2.43215 2.24684 2.3247 1.90433 2.3247C1.58196 2.3247 1.33347 2.43215 1.15885 2.64707C0.984237 2.86198 0.896929 3.15076 0.896929 3.51343ZM6.26895 4.47045C6.35626 4.47045 6.41335 4.50068 6.44021 4.56112C6.47379 4.61485 6.49058 4.6988 6.49058 4.81297C6.49058 4.93386 6.47379 5.02452 6.44021 5.08497C6.41335 5.13869 6.35626 5.16556 6.26895 5.16556H4.60675C4.51944 5.16556 4.46235 5.13869 4.43549 5.08497C4.40191 5.03124 4.38512 4.94729 4.38512 4.83312C4.38512 4.71223 4.40191 4.62156 4.43549 4.56112C4.46235 4.50068 4.51944 4.47045 4.60675 4.47045H6.26895ZM7.93155 4.47045C8.01886 4.47045 8.07594 4.50068 8.10281 4.56112C8.13639 4.61485 8.15318 4.6988 8.15318 4.81297C8.15318 4.93386 8.13639 5.02452 8.10281 5.08497C8.07594 5.13869 8.01886 5.16556 7.93155 5.16556H6.26935C6.18204 5.16556 6.12495 5.13869 6.09809 5.08497C6.06451 5.03124 6.04772 4.94729 6.04772 4.83312C6.04772 4.71223 6.06451 4.62156 6.09809 4.56112C6.12495 4.50068 6.18204 4.47045 6.26935 4.47045H7.93155ZM9.59415 4.47045C9.68146 4.47045 9.73854 4.50068 9.76541 4.56112C9.79899 4.61485 9.81578 4.6988 9.81578 4.81297C9.81578 4.93386 9.79899 5.02452 9.76541 5.08497C9.73854 5.13869 9.68146 5.16556 9.59415 5.16556H7.93194C7.84464 5.16556 7.78755 5.13869 7.76069 5.08497C7.72711 5.03124 7.71032 4.94729 7.71032 4.83312C7.71032 4.71223 7.72711 4.62156 7.76069 4.56112C7.78755 4.50068 7.84464 4.47045 7.93194 4.47045H9.59415ZM11.2567 4.47045C11.3441 4.47045 11.4011 4.50068 11.428 4.56112C11.4616 4.61485 11.4784 4.6988 11.4784 4.81297C11.4784 4.93386 11.4616 5.02452 11.428 5.08497C11.4011 5.13869 11.3441 5.16556 11.2567 5.16556H9.59454C9.50723 5.16556 9.45015 5.13869 9.42328 5.08497C9.3897 5.03124 9.37291 4.94729 9.37291 4.83312C9.37291 4.71223 9.3897 4.62156 9.42328 4.56112C9.45015 4.50068 9.50723 4.47045 9.59454 4.47045H11.2567ZM12.1638 4.47045C12.4257 4.47045 12.6339 4.39994 12.7884 4.2589C12.9496 4.11787 13.0302 3.9231 13.0302 3.67461V2.2844H13.685V3.67461C13.685 4.15144 13.5506 4.52082 13.282 4.78275C13.0201 5.03795 12.6608 5.16556 12.2041 5.16556H11.2571C11.1698 5.16556 11.1127 5.13869 11.0859 5.08497C11.0523 5.03124 11.0355 4.94729 11.0355 4.83312C11.0355 4.71223 11.0523 4.62156 11.0859 4.56112C11.1127 4.50068 11.1698 4.47045 11.2571 4.47045H12.1638ZM13.7857 0.994934H12.9798V0.279683H13.7857V0.994934ZM12.5063 0.994934H11.7004V0.279683H12.5063V0.994934ZM5.64177 12.9641C5.64177 13.3267 5.58468 13.6659 5.47051 13.9815C5.35634 14.3039 5.1918 14.5826 4.97689 14.8177C4.76198 15.0595 4.50005 15.2509 4.19112 15.3919C3.8889 15.5329 3.54638 15.6035 3.16357 15.6035H2.56921C1.81702 15.6035 1.23273 15.3718 0.816337 14.9084C0.399946 14.445 0.191751 13.8103 0.191751 13.0044V11.2414H0.836485V12.9842C0.836485 13.273 0.870065 13.5349 0.937225 13.77C1.0111 14.0051 1.12191 14.2065 1.26967 14.3744C1.42413 14.549 1.61554 14.6834 1.84388 14.7774C2.07223 14.8714 2.34758 14.9184 2.66995 14.9184H3.1132C3.42885 14.9184 3.70421 14.8647 3.93927 14.7572C4.17433 14.6565 4.36909 14.5188 4.52356 14.3442C4.68474 14.1696 4.80227 13.9648 4.87615 13.7297C4.95674 13.4946 4.99703 13.2495 4.99703 12.9943V10.2844H5.64177V12.9641ZM3.21394 10.0628H2.36773V9.32738H3.21394V10.0628ZM8.24526 13.1656C8.07064 13.1656 7.90274 13.1421 7.74156 13.095C7.58038 13.0413 7.43598 12.954 7.30838 12.8331C7.18749 12.7122 7.09011 12.5544 7.01624 12.3596C6.94236 12.1582 6.90542 11.9097 6.90542 11.6142V6.9197H7.56023V11.4933C7.56023 11.7754 7.62067 12.0104 7.74156 12.1985C7.86916 12.3798 8.074 12.4705 8.35607 12.4705H8.52733C8.67508 12.4705 8.74896 12.5846 8.74896 12.813C8.74896 13.048 8.67508 13.1656 8.52733 13.1656H8.24526ZM8.69324 12.4705C8.95516 12.4705 9.15328 12.4067 9.2876 12.279C9.42192 12.1514 9.48908 11.9802 9.48908 11.7653V11.3825C9.48908 10.7982 9.63683 10.3415 9.93233 10.0124C10.2346 9.68332 10.6509 9.51878 11.1815 9.51878C11.4569 9.51878 11.6986 9.56243 11.9068 9.64974C12.115 9.73705 12.2863 9.8613 12.4206 10.0225C12.5616 10.1837 12.6657 10.3751 12.7329 10.5967C12.8001 10.8183 12.8336 11.0635 12.8336 11.3321C12.8336 11.9097 12.6825 12.3596 12.3803 12.682C12.0781 13.0044 11.6651 13.1656 11.1412 13.1656C10.8726 13.1656 10.614 13.1152 10.3655 13.0144C10.117 12.907 9.92226 12.7189 9.78123 12.4503C9.72078 12.6048 9.64691 12.729 9.5596 12.823C9.47229 12.9171 9.38162 12.9909 9.2876 13.0447C9.19358 13.0917 9.09284 13.1253 8.98538 13.1454C8.88464 13.1588 8.78726 13.1656 8.69324 13.1656H8.53205C8.44475 13.1656 8.38766 13.1387 8.3608 13.085C8.32722 13.0312 8.31043 12.9473 8.31043 12.8331C8.31043 12.7122 8.32722 12.6216 8.3608 12.5611C8.38766 12.5007 8.44475 12.4705 8.53205 12.4705H8.69324ZM12.1889 11.3925C12.1889 11.0433 12.1117 10.7612 11.9572 10.5463C11.8027 10.3247 11.5375 10.2139 11.1614 10.2139C10.4629 10.2139 10.1137 10.6202 10.1137 11.4328C10.1137 11.7754 10.2077 12.0339 10.3957 12.2085C10.5905 12.3831 10.839 12.4705 11.1412 12.4705C11.4837 12.4705 11.7423 12.3764 11.9169 12.1884C12.0982 12.0003 12.1889 11.7351 12.1889 11.3925Z" fill="currentColor"></path></svg>\n'
document.querySelectorAll('.money-icon').forEach( EL =>{
    EL.innerHTML = PriceIcon
});


function showElement(element, displayType = 'block') {
    if (element) {
        element.style.display = displayType;
    }
}

function hideElement(element) {
    if (element) {
        element.style.display = 'none';
    }
}

function activateOverlay(overlayElement) {
    if (overlayElement) {
        overlayElement.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function deactivateOverlay(overlayElement) {
    if (overlayElement) {
        overlayElement.classList.remove('active');
        document.body.style.overflow = '';
    }
}


const mobileMenuOpenBtn = document.querySelectorAll('[data-mobile-menu-open-btn]');
const mobileMenu = document.querySelectorAll('[data-mobile-menu]');
const mobileMenuCloseBtn = document.querySelectorAll('[data-mobile-menu-close-btn]');
const overlay = document.querySelector('[data-overlay]');

for (let i = 0; i < mobileMenuOpenBtn.length; i++) {

    const mobileMenuCloseFunc = function () {
        mobileMenu[i].classList.remove('active');
        overlay.classList.remove('active');
    }

    mobileMenuOpenBtn[i].addEventListener('click', function () {
        mobileMenu[i].classList.add('active');
        overlay.classList.add('active');

    })

    mobileMenuCloseBtn[i].addEventListener('click', mobileMenuCloseFunc);
    overlay.addEventListener('click', mobileMenuCloseFunc);
}

const accordionBtn = document.querySelectorAll('[data-accordion-btn]');
const accordion = document.querySelectorAll('[data-accordion]');

for (let i = 0; i < accordion.length; i++) {
    accordionBtn[i].addEventListener('click', function () {
        const clickedBtn = this.nextElementSibling.classList.contains('active');

        for (let i = 0; i < accordion.length; i++) {
            if (clickedBtn) break;
            if (accordion[i].classList.contains('active')) {
                accordion[i].classList.remove('active');
                accordionBtn[i].classList.remove('active');
            }
        }

        this.nextElementSibling.classList.toggle('active');
        this.classList.toggle('active');
    })
}


let mainOverlay;
let searchBoxInstance;
let cartDashboardInstance;


document.addEventListener('DOMContentLoaded', function() {

    mainOverlay = document.querySelector('.overlay');
    searchBoxInstance = $('.search-box'); // jQuery
    cartDashboardInstance = document.getElementById('cart-dashboard');

    const tooltipTriggerList = Array.from(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

    if (mainOverlay) {
        mainOverlay.addEventListener('click', () => {
            if (searchBoxInstance && searchBoxInstance.hasClass('show-modal-style')) {
                searchBoxInstance.removeClass('show-modal-style').addClass('search-box');
            }
            if (cartDashboardInstance && cartDashboardInstance.classList.contains('show-dashboard')) {
                cartDashboardInstance.classList.remove('show-dashboard');
                cartDashboardInstance.classList.add('hidden-dashboard');
            }
            document.querySelectorAll('[data-mobile-menu].active').forEach(menu => menu.classList.remove('active'));


            deactivateOverlay(mainOverlay);
        });
    }

    const mobileMenuOpenBtns = document.querySelectorAll('[data-mobile-menu-open-btn]');
    const mobileMenus = document.querySelectorAll('[data-mobile-menu]');
    const mobileMenuCloseBtns = document.querySelectorAll('[data-mobile-menu-close-btn]');

    mobileMenuOpenBtns.forEach((btn, index) => {
        const currentMobileMenu = mobileMenus[index];
        if (!currentMobileMenu) return;

        btn.addEventListener('click', () => {
            currentMobileMenu.classList.add('active');
            if (mainOverlay) activateOverlay(mainOverlay);
        });

        if (mobileMenuCloseBtns[index]) {
            mobileMenuCloseBtns[index].addEventListener('click', () => {
                currentMobileMenu.classList.remove('active');
                if (mainOverlay) deactivateOverlay(mainOverlay);
            });
        }
    });


    const accordionContainer = document.querySelector('.accordion-container');
    if (accordionContainer) {
        accordionContainer.addEventListener('click', function(event) {
            const accordionButton = event.target.closest('[data-accordion-btn]');
            if (!accordionButton) return;

            const currentPanel = accordionButton.nextElementSibling;
            if (!currentPanel || !currentPanel.matches('[data-accordion]')) return;

            const isAlreadyActive = currentPanel.classList.contains('active');

            // Close all other accordions in this container
            accordionContainer.querySelectorAll('[data-accordion].active').forEach(panel => {
                if (panel !== currentPanel) {
                    panel.classList.remove('active');
                    const prevButton = panel.previousElementSibling;
                    if (prevButton && prevButton.matches('[data-accordion-btn]')) {
                        prevButton.classList.remove('active');
                    }
                }
            });

            currentPanel.classList.toggle('active', !isAlreadyActive);
            accordionButton.classList.toggle('active', !isAlreadyActive);
        });
    } else {
        const allAccordionBtns = document.querySelectorAll('[data-accordion-btn]');
        allAccordionBtns.forEach(button => {
            button.addEventListener('click', function() {
            });
        });
    }


    const showSearchBoxBtn = $('.show-search-modal');
    const closeModalSearchBtn = $('.close-modal'); // Assuming this is for search modal

    showSearchBoxBtn.on('click', function () {
        searchBoxInstance.removeClass('search-box').addClass('show-modal-style');
        if (mainOverlay) activateOverlay(mainOverlay);
    });
    closeModalSearchBtn.on('click', function () {
        searchBoxInstance.removeClass('show-modal-style').addClass('search-box');
        if (mainOverlay) deactivateOverlay(mainOverlay);
    });


    if (typeof Swiper !== 'undefined' && document.querySelector(".mySwiper")) {
        new Swiper(".mySwiper", {
            spaceBetween: 30,
            effect: "fade",
            navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" },
            pagination: { el: ".swiper-pagination", clickable: true },
            autoplay: { delay: 3000, disableOnInteraction: false },
            loop: true, // Often desired for fade effect
        });
    }

    let cartItemsData = JSON.parse(localStorage.getItem('cartItems')) || [];

    function updateCartDisplay() {
        const cartList = document.getElementById('cart-items');
        if (!cartList) return;
        cartList.innerHTML = '';
        let totalPrice = 0;
        const itemCounts = {};
        cartItemsData.forEach(item => {
            itemCounts[item.name] = itemCounts[item.name] || { count: 0, image: item.image, price: item.price };
            itemCounts[item.name].count++;
        });
        for (const [productName, { count, image, price }] of Object.entries(itemCounts)) {
            const cartItem = document.createElement('li');
            cartItem.className = 'cart-item'; // Use className for single class
            const img = document.createElement('img');
            img.src = image; img.alt = productName; img.style.width = '90px';
            const nameDiv = document.createElement('div');
            nameDiv.style.cssText = "width: 100%; white-space: nowrap; font-size: 12px;"; nameDiv.textContent = productName;
            cartItem.appendChild(nameDiv); cartItem.appendChild(img);
            totalPrice += price * count;
            cartItem.appendChild(createCartActionButton('+', () => addProductToCart(productName, image, price)));
            cartItem.appendChild(createCartActionButton('-', () => removeSingleProductFromCart(productName)));
            cartItem.appendChild(createCartActionButton('delete', () => removeFullProductFromCart(productName)));
            const countSpan = document.createElement('span'); countSpan.className = 'count'; countSpan.textContent = `تعداد محصول: ${count}`; countSpan.style.marginTop = '10px';
            const priceSpan = document.createElement('span'); priceSpan.className = 'price'; priceSpan.textContent = `قیمت محصول: ${price} تومان`; priceSpan.style.cssText = 'font-size: 13px; margin-top: 10px;';
            cartItem.appendChild(countSpan); cartItem.appendChild(priceSpan);
            cartList.appendChild(cartItem);
        }
        if (Object.keys(itemCounts).length === 0) {
            cartList.innerHTML = '<div class="empty-cart-message">سبد خرید شما خالی است.</div>';
        }
        const totalPriceElement = document.getElementById('total-price');
        if (totalPriceElement) totalPriceElement.textContent = `جمع کل: ${totalPrice} تومان`;
        localStorage.setItem('cartItems', JSON.stringify(cartItemsData));
    }

    function createCartActionButton(type, onClick) {
        const button = document.createElement('span');
        button.classList.add('icon-button');
        let svgHTML = '';
        if (type === '+') {
            svgHTML = `<svg class="plus" style="position: absolute" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="0.9em" height="1em"><path fill="none" stroke="currentColor" stroke-linecap="round" d="M12 3.5v17m8.5-8.5h-17"></path></svg>`;
        } else if (type === '-') {
            svgHTML = `<svg class="minus" style="position: absolute" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="0.9em" height="1em"><path fill="currentColor" d="M72 240h368v32H72z"></path></svg>`;
        } else if (type === 'delete') {
            button.classList.add('delete-button');
            svgHTML = `<svg class="delete position-absolute" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="1.2em" height="1.2em"><path fill="currentColor" d="M14.885 17.5v-1h3v1zm0-8v-1h6v1zm0 4v-1h5v1zM4.115 8h-1V7h3.731v-.885h2.538V7h3.732v1h-1v10h-8zm1 0v9h6V8zm0 0v9z"></path></svg>`;
        }
        button.innerHTML = svgHTML;
        button.addEventListener('click', onClick);
        return button;
    }

    function addProductToCart(productName, image, price) {
        const priceNumber = Number(price);
        if (isNaN(priceNumber)) { console.error("Invalid product price for add."); return; }
        cartItemsData.push({ name: productName, image: image, price: priceNumber });
        updateCartDisplay();
        if (cartDashboardInstance) {
            cartDashboardInstance.classList.add('show-dashboard');
            cartDashboardInstance.classList.remove('hidden-dashboard');
        }
        if (mainOverlay) activateOverlay(mainOverlay);
    }

    function removeSingleProductFromCart(productName) {
        const index = cartItemsData.findIndex(item => item.name === productName);
        if (index > -1) cartItemsData.splice(index, 1);
        updateCartDisplay();
        if (cartItemsData.length === 0 && cartDashboardInstance && mainOverlay) {
            cartDashboardInstance.classList.remove('show-dashboard');
            cartDashboardInstance.classList.add('hidden-dashboard');
            deactivateOverlay(mainOverlay);
        }
    }

    function removeFullProductFromCart(productName) {
        cartItemsData = cartItemsData.filter(item => item.name !== productName);
        updateCartDisplay();
        if (cartItemsData.length === 0 && cartDashboardInstance && mainOverlay) {
            cartDashboardInstance.classList.remove('show-dashboard');
            cartDashboardInstance.classList.add('hidden-dashboard');
            deactivateOverlay(mainOverlay);
        }
    }

    document.body.addEventListener('click', function(event){
        const addToCartButton = event.target.closest('.add-to-cart');
        if(addToCartButton){
            const productCard = addToCartButton.closest('article');
            if(!productCard) { console.error("Add to cart: Product card (article) not found."); return; }

            const productName = productCard.querySelector('.product img.one-img')?.alt;
            const productImage = productCard.querySelector('.product img.one-img')?.src;
            const productPriceElement = productCard.querySelector('span.price');

            if (productName && productImage && productPriceElement) {
                const productPriceText = productPriceElement.textContent.match(/[\d\.]+/);
                const productPrice = productPriceText ? parseFloat(productPriceText[0]) : NaN;
                if (!isNaN(productPrice)) {
                    addProductToCart(productName, productImage, productPrice);
                } else { console.error("Invalid product price format from add-to-cart.", productPriceElement.textContent); }
            } else { console.error("Missing product details for add-to-cart.", {productName, productImage, productPriceElement}); }
        }
    });

    updateCartDisplay();

    const closeCartButton = document.getElementById('close-cart');
    if (closeCartButton && cartDashboardInstance) {
        closeCartButton.addEventListener('click', () => {
            cartDashboardInstance.classList.remove('show-dashboard');
            cartDashboardInstance.classList.add('hidden-dashboard');
            if (mainOverlay) deactivateOverlay(mainOverlay);
        });
    }

    let totalLikesCount = 0;
    const totalLikesDisplayElement = document.getElementById('total-likes');

    document.querySelectorAll('.like[data-likes]').forEach(btn => {
        totalLikesCount += parseInt(btn.getAttribute('data-likes')) || 0;
    });
    if (totalLikesDisplayElement) totalLikesDisplayElement.textContent = totalLikesCount;

    document.body.addEventListener('click', function(event) {
        const likeButton = event.target.closest('.like');
        if (likeButton) {
            const colorLikeElement = likeButton.querySelector('.svg-tag');
            let numLikes = parseInt(likeButton.getAttribute('data-likes')) || 0;
            const isLiked = likeButton.getAttribute('data-liked') === 'true';

            if (!isLiked) {
                numLikes++; totalLikesCount++;
                if(colorLikeElement) colorLikeElement.setAttribute('fill', 'currentColor');
                likeButton.setAttribute('data-liked', 'true');
            } else {
                numLikes--; totalLikesCount--;
                if(colorLikeElement) colorLikeElement.setAttribute('fill', 'none');
                likeButton.setAttribute('data-liked', 'false');
            }
            likeButton.setAttribute('data-likes', numLikes);
            if (totalLikesDisplayElement) totalLikesDisplayElement.textContent = totalLikesCount;
        }
    });

    const shopIconButton = document.querySelector('.shop-icon');
    if (shopIconButton && cartDashboardInstance) {
        shopIconButton.addEventListener('click', () => {
            cartDashboardInstance.classList.add('show-dashboard');
            cartDashboardInstance.classList.remove('hidden-dashboard');
            if (mainOverlay) activateOverlay(mainOverlay);
        });
    }

    const csSpaceContainer = document.querySelector('.cs-space-container');
    if (csSpaceContainer) {
        csSpaceContainer.addEventListener('click', function(event) {
            const button = event.target.closest('.cs-space');
            if (button) {
                csSpaceContainer.querySelectorAll('.cs-space.active-cs').forEach(btn => btn.classList.remove('active-cs'));
                button.classList.add('active-cs');
            }
        });
    }


    const megaMenuTriggerDesktop = document.getElementById('mega-menu-trigger-btn-desktop');
    const megaMenuPanelDesktop = document.getElementById('mega-menu-panel-content-desktop');
    if (megaMenuTriggerDesktop && megaMenuPanelDesktop) {
        let megaMenuTimeoutIdDesktop = null;
        let isMouseInsidePanelOrTriggerDesktop = false;
        const hideDelay = 250;
        const categoryItems = megaMenuPanelDesktop.querySelectorAll('.mega-category-item');
        const contentPanes = megaMenuPanelDesktop.querySelectorAll('.mega-menu-pane');
        const showMenu = () => { isMouseInsidePanelOrTriggerDesktop = true; clearTimeout(megaMenuTimeoutIdDesktop); megaMenuPanelDesktop.classList.add('show'); const firstCategory = categoryItems[0]; if (firstCategory && !megaMenuPanelDesktop.querySelector('.mega-category-item.active')) { activateTab(firstCategory); } };
        const hideMenu = () => { isMouseInsidePanelOrTriggerDesktop = false; megaMenuTimeoutIdDesktop = setTimeout(() => { if (!isMouseInsidePanelOrTriggerDesktop) { megaMenuPanelDesktop.classList.remove('show'); categoryItems.forEach(item => item.classList.remove('active')); contentPanes.forEach(pane => pane.classList.remove('active')); } }, hideDelay); };
        const activateTab = (categoryElement) => { /* ... */ const targetPaneId = categoryElement.dataset.target; if (!targetPaneId) return; const targetPane = megaMenuPanelDesktop.querySelector(targetPaneId); if (!targetPane) return; categoryItems.forEach(item => item.classList.remove('active')); contentPanes.forEach(pane => pane.classList.remove('active')); categoryElement.classList.add('active'); targetPane.classList.add('active'); };
        megaMenuTriggerDesktop.addEventListener('mouseenter', showMenu);
        megaMenuTriggerDesktop.addEventListener('mouseleave', hideMenu);
        megaMenuPanelDesktop.addEventListener('mouseenter', () => { isMouseInsidePanelOrTriggerDesktop = true; clearTimeout(megaMenuTimeoutIdDesktop); });
        megaMenuPanelDesktop.addEventListener('mouseleave', hideMenu);
        categoryItems.forEach(item => { item.addEventListener('mouseenter', () => { clearTimeout(megaMenuTimeoutIdDesktop); isMouseInsidePanelOrTriggerDesktop = true; activateTab(item); }); });
        document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && megaMenuPanelDesktop.classList.contains('show')) { clearTimeout(megaMenuTimeoutIdDesktop); megaMenuPanelDesktop.classList.remove('show'); isMouseInsidePanelOrTriggerDesktop = false; categoryItems.forEach(item => item.classList.remove('active')); contentPanes.forEach(pane => pane.classList.remove('active')); } });
    }


    const themeToggleButtonTest = document.getElementById('theme-toggle-btn-test');
    const htmlElement = document.documentElement;
    function applyTheme(theme) { if (theme === 'dark') { htmlElement.setAttribute('data-theme', 'dark'); } else { htmlElement.removeAttribute('data-theme'); } localStorage.setItem('theme', theme); }
    const savedTheme = localStorage.getItem('theme') || 'light'; applyTheme(savedTheme);
    if (themeToggleButtonTest) { themeToggleButtonTest.addEventListener('click', () => { const currentTheme = htmlElement.hasAttribute('data-theme') ? 'dark' : 'light'; const newTheme = currentTheme === 'dark' ? 'light' : 'dark'; applyTheme(newTheme); }); }

    // بخش مربوط به HTML Quick View Modal و توابع آن و Event Listener مربوط به دکمه "view" حذف شد
});

$(document).ready(function(){
    if (typeof $.fn.owlCarousel !== 'undefined' && $(".owl-carousel").length) {
        $(".owl-carousel").owlCarousel({
            rtl: true, loop: true, margin: 20, nav: true, dots: true,
            autoplay: true, autoplayTimeout: 3000, autoplayHoverPause: true,
            responsiveClass:true,
            responsive:{ 0:{ items:1, nav:false }, 600:{ items:3, nav:true }, 1000:{ items:4 }, 1200:{ items:5 } }
        });
    }
});

function showToast(type, title, message, duration = 4000) {
    const container = document.getElementById('notificationToastContainer');
    if (!container) {
        console.error('Notification container #notificationToastContainer not found!');
        return;
    }
    const iconMap = {
        success: '#icon-check-circle-fill',
        error: '#icon-alert-triangle-fill',
        info: '#icon-info-circle-fill'
    };
    const toastDiv = document.createElement('div');
    toastDiv.className = `wow-notification-new ${type}`;
    toastDiv.innerHTML = `
        <div class="wow-notification-icon-new">
            <svg><use xlink:href="${iconMap[type] || '#icon-info-circle-fill'}"></use></svg>
        </div>
        <div class="wow-notification-content-new">
            <div class="wow-notification-title-new">${title}</div>
            <div class="wow-notification-message-new">${message}</div>
        </div>
        <button class="wow-notification-close-new">×</button>`;

    container.appendChild(toastDiv);

    requestAnimationFrame(() => {
        toastDiv.classList.add('show');
    });

    const removeToast = () => {
        toastDiv.classList.remove('show');
        setTimeout(() => {
            toastDiv.remove();
        }, 400);
    };

    toastDiv.querySelector('.wow-notification-close-new').onclick = removeToast;

    if (duration > 0) {
        setTimeout(removeToast, duration);
    }
}


document.addEventListener('DOMContentLoaded', () => {

    const searchModalTriggers = document.querySelectorAll('.show-search-modal');
    const searchBox = document.querySelector('.search-box');
    const closeSearchModal = document.querySelector('.search-box .close-modal');

    if (searchBox) {
        searchModalTriggers.forEach(trigger => {
            trigger.addEventListener('click', () => {
                searchBox.classList.add('active');
            });
        });

        closeSearchModal.addEventListener('click', () => {
            searchBox.classList.remove('active');
        });
    }
});




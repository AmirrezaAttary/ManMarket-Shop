from django.db import models
# Create your models here.
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.contrib.auth.base_user import BaseUserManager
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.db import models
from ...wallets.models import Wallet
from ...accounts.validators import validate_iranian_cellphone_number



class UserType(models.IntegerChoices):
    customer = 1, "مشتری"
    admin = 2, "ادمین"
    superuser = 3, "سوپر یوزر"


class UserManager(BaseUserManager):

    def create_user(self, phone_number, password=None, **extra_fields):
        if not phone_number:
            raise ValueError("Phone number is required")

        user = self.model(phone_number=phone_number, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, phone_number, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("is_verified", True)
        extra_fields.setdefault("type", UserType.superuser.value)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self.create_user(phone_number, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):

    email = models.EmailField(_("email address"), unique=False, null=True, blank=True)
    phone_number = models.CharField(
        max_length=12,
        unique=True,
        validators=[validate_iranian_cellphone_number],
        default='09120000000', verbose_name="شماره موبایل"
    )
    
    is_staff = models.BooleanField(default=False, verbose_name="دسترسی به ادمین جنگو")
    is_active = models.BooleanField(default=True, verbose_name="فعال")
    is_verified = models.BooleanField(default=False, verbose_name="تایید شده")
    code_melli = models.CharField(max_length=10,unique=True,null=True,blank=True, verbose_name="کد ملی")
    type = models.IntegerField(
        choices=UserType.choices, default=UserType.customer.value, verbose_name="نوع کاربر")

    created_date = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ایجاد")
    updated_date = models.DateTimeField(auto_now=True, verbose_name="آخرین ویرایش")

    USERNAME_FIELD = 'phone_number'
    REQUIRED_FIELDS = []

    objects = UserManager()

    def __str__(self):
        if self.email:
            return str(self.email)
        elif self.phone_number:
            return str(self.phone_number)
        return f"User #{self.pk}"

    class Meta:
        verbose_name = "کاربر"
        verbose_name_plural = "کاربران"
        ordering = ['-phone_number']

class Profile(models.Model):
    user = models.OneToOneField('User', on_delete=models.CASCADE,related_name="user_profile", verbose_name="کاربر")
    first_name = models.CharField(max_length=255,null=True,blank=True, verbose_name="نام")
    last_name = models.CharField(max_length=255,null=True,blank=True, verbose_name="نام خانوادگی")

    image = models.ImageField(upload_to='profile/',default='default/default-profile.webp', verbose_name="تصویر پروفایل")
    created_date = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ایجاد")
    updated_date = models.DateTimeField(auto_now=True, verbose_name="آخرین ویرایش")
    birth_date = models.CharField(max_length=10, null=True, blank=True, help_text="تاریخ تولد را وارد کنید (مثلاً 1375-05-10)", verbose_name="تاریخ تولد")

    # def age(self):
    #     """محاسبه‌ی سن کاربر بر اساس birth_date"""
    #     if self.birth_date:
    #         today = date.today()
    #         return today.year - self.birth_date.year - (
    #             (today.month, today.day) < (self.birth_date.month, self.birth_date.day)
    #         )
    #     return None

    def get_fullname(self):
        name = " ".join(filter(None, [self.first_name, self.last_name]))
        return name if name else "کاربر جدید"

    class Meta:
        verbose_name = "پروفایل"
        verbose_name_plural = "پروفایل‌ها"
    
    
    
    
@receiver(post_save,sender=User)
def create_profile(sender,instance,created,**kwargs):
    if created and instance.type == UserType.customer.value:
        Profile.objects.create(user=instance, pk=instance.pk)
        

@receiver(post_save, sender=User)
def create_wallet(sender, instance, created, **kwargs):
    if created:
        Wallet.objects.create(user=instance)
from django.db import models
from ..shop.models import ProductModel
from django.core.validators import MaxValueValidator, MinValueValidator
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.db.models import Avg
from django.utils import timezone
from .utils import clean_review_text
# Create your models here.


class ReviewStatusType(models.IntegerChoices):
    pending = 1, "در انتظار تایید"
    accepted = 2, "تایید شده"
    rejected = 3, "رد شده"


class ReviewModel(models.Model):
    user = models.ForeignKey('accounts.User', on_delete=models.CASCADE,related_name='reviw_user',blank=True,null=True, verbose_name="کاربر")
    product = models.ForeignKey('shop.ProductModel',on_delete=models.CASCADE, related_name='reviews', verbose_name="محصول")
    name = models.CharField(max_length=200, blank=True, null=True, verbose_name="نام")
    description = models.TextField(verbose_name="متن نظر")
    rate = models.IntegerField(default=5, validators=[
                               MinValueValidator(0), MaxValueValidator(5)], verbose_name="امتیاز")
    status = models.IntegerField(
        choices=ReviewStatusType.choices, default=ReviewStatusType.pending.value, verbose_name="وضعیت نظر")
    created_date = models.DateTimeField(default=timezone.now, verbose_name="تاریخ ایجاد")  
    updated_date = models.DateTimeField(auto_now=True, verbose_name="آخرین ویرایش")

    class Meta:
        verbose_name = "نظر"
        verbose_name_plural = "نظرات"
        ordering = ["-created_date"]
    
    def __str__(self):
        return f"{self.user} - {self.product.id}"

    def save(self, *args, **kwargs):
        # نظرها همیشه متن ساده ذخیره می‌شوند (نظرات اسکرپ‌شده از دیجی‌کالا HTML دارند)
        self.description = clean_review_text(self.description)
        super().save(*args, **kwargs)
    
    
    def get_status(self):
        return {
            "id":self.status,
            "title":ReviewStatusType(self.status).name,
            "label":ReviewStatusType(self.status).label,
        }
        
        
@receiver(post_save,sender=ReviewModel)
def calculate_avg_review(sender,instance,created,**kwargs):
    if instance.status == ReviewStatusType.accepted.value:
        product = instance.product
        average_rating = ReviewModel.objects.filter(product=product, status=ReviewStatusType.accepted).aggregate(Avg('rate'))['rate__avg']
        product.avg_rate = round(average_rating,1)
        product.save()
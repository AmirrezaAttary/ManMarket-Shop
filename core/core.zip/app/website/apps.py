from django.apps import AppConfig


class WebsiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app.website'
    verbose_name = "وب‌سایت"
    
    def ready(self):
        from . import signals
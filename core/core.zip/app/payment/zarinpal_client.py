import requests
import json
from django.conf import settings

class ZarinPalSandbox:
    _payment_request_url = "https://payment.zarinpal.com/pg/v4/payment/request.json"
    _payment_verify_url = "https://payment.zarinpal.com/pg/v4/payment/verify.json"
    _payment_page_url = "https://payment.zarinpal.com/pg/StartPay/"


    def __init__(self, merchant_id=settings.MERCHANT_ID):
        self.merchant_id = merchant_id

    def payment_request(self,callback_url, amount, description="پرداختی کاربر"):
        payload = {
            "merchant_id": self.merchant_id,
            "amount": str(amount),
            "callback_url": callback_url,
            "description": description,
            'currency':'IRT'
        }
        headers = {
            'Content-Type': 'application/json'
        }

        response = requests.post(
            self._payment_request_url, headers=headers, data=json.dumps(payload))

        return response.json()

    def payment_verify(self,amount,authority):
        payload = {
            "merchant_id": self.merchant_id,
            "amount": amount,
            "authority": authority
        }
        headers = {
            'Content-Type': 'application/json'
        }

        response = requests.post(self._payment_verify_url, headers=headers, data=json.dumps(payload))
        return response.json()

    def generate_payment_url(self,authority):
        return f"{self._payment_page_url}{authority}"